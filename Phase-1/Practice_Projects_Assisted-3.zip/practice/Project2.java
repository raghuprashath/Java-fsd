package practice;

import java.util.Arrays;
import java.util.Scanner;

public class Project2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the Array Elements");
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		if(n<4) {
			System.out.println("The size of element is less than 4.Unable to find fourth smallest elment");
		}
		else {
			Arrays.sort(arr);
			System.out.println("The Fourth Smallest Element is "+arr[3]);
		}
	}
}
