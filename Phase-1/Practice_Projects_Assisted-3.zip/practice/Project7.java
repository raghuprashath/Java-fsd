package practice;

import java.util.Scanner;

public class Project7 {
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        DoublyLinkedList dll=new DoublyLinkedList();
        while(true){
            System.out.println("Do you Want to add element(y/n)");
            char ch=sc.next().charAt(0);
            if (ch=='Y'||ch=='y'){
                System.out.println("Enter the Element ");
                int x=sc.nextInt();
                dll.insert(x);
            } else{
                break;
            }
        }
        System.out.print("Forward traversal: ");
        dll.forwardTraversal();
        System.out.print("Backward traversal: ");
        dll.backwardTraversal();
    }
}
class Node2{
    int data;
    Node2 prev;
    Node2 next;
    Node2(int d){
        data=d;
        prev=null;
        next=null;
    }
}
class DoublyLinkedList{
    Node2 head;
    DoublyLinkedList(){
        head=null;
    }
    void insert(int data){
        Node2 newNode = new Node2(data);
        if(head==null){
            head=newNode;
            return;
        }
        Node2 current=head;
        while(current.next!=null){
            current=current.next;
        }
        current.next=newNode;
        newNode.prev=current;
    }
    void forwardTraversal(){
        if(head==null){
            System.out.println("List is empty");
            return;
        }
        Node2 current=head;
        while(current!=null){
            System.out.print(current.data + " ");
            current=current.next;
        }
        System.out.println();
    }
    void backwardTraversal(){
        if (head==null){
            System.out.println("List is empty");
            return;
        }
        Node2 current=head;
        while(current.next!=null){
            current=current.next;
        }
        while(current!=null){
            System.out.print(current.data + " ");
            current=current.prev;
        }
        System.out.println();
    }
}
