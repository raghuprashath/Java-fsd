package practice;

import java.util.Scanner;

public class Project5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Singlylinkedlist ll=new Singlylinkedlist();
		while(true) {
			System.out.println("Do you Want to add element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println("Enter the Element ");
				int x=sc.nextInt();
				ll.add(x);
			}
			else {
				break;
			}
		}
		System.out.println("Current Linked list");
		ll.display();
		System.out.println("Enter the Number you want to delete");
		int n=sc.nextInt();
		ll.deletenode(n);
		System.out.println("Linked List After Deleting");
		ll.display();
	}
}
class node
{
	int data;
	node next;
	node(int data)
	{
		this.data=data;
		next=null;
	}
}
class Singlylinkedlist
{
	node head;
	public Singlylinkedlist()
	{
		head=null;
	}

	public boolean isEmpty()
	{
		return head==null;
	}
	public void add(int data)
	{
		node newnode=new node(data);
		if(head==null)
		{
			head=newnode;
		}
		else
		{
			node temp=head;
			while(temp.next!=null)
			{
				temp=temp.next;
			}
			temp.next=newnode;
		}
	    
	}
	
	public int remove()
	{
		if(isEmpty())
		{
			System.out.println("Linkedlist is empty");
			return 0;
		}
		else
		{
			int data=head.data;
			head=head.next;
			return data;
		}
	}
	public void deletenode(int n) {
	    node temp=head;
	    node prev=null;
	    if(head==null){
	        System.out.println("Linked list is empty");
	        return;
	    }
	    if(head.data==n){
	        head=head.next;
	        return;
	    }
	    while (temp!=null&&temp.data!=n) {
	        prev=temp;
	        temp=temp.next;
	    }
	    if(temp==null){
	        System.out.println("Number not found in the linked list");
	        return;
	    }
	    prev.next=temp.next;
	}
	public void display() 
	{
        node temp = head;
        while (temp != null) 
        {
            System.out.print(temp.data+ " ");
            temp = temp.next;
        }
        System.out.println();
    }
}