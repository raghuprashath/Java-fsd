package practice;

import java.util.Scanner;

public class Project6{
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        CircularLinkedList cll=new CircularLinkedList();
        while(true) {
			System.out.println("Do you Want to add element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println("Enter the Element ");
				int x=sc.nextInt();
				cll.insert(x);
			}
			else {
				break;
			}
        }
        System.out.println("Circular Linked List");
        cll.display();
    }
}

class Node1{
    int data;
    Node1 next;
    public Node1(int data){
        this.data=data;
        this.next=null;
    }
}

class CircularLinkedList{
    Node1 head;
    public CircularLinkedList(){
        this.head = null;
    }
    public void insert(int data){
        Node1 newNode=new Node1(data);
        if (head==null){ 
            head=newNode;
            head.next=head;
            return;
        }
        Node1 current=head;
        if (newNode.data<head.data){
            while (current.next!=head)
                current = current.next;

            current.next = newNode;
            newNode.next = head;
            head = newNode;
            return;
        }
        while(current.next!=head&&current.next.data<newNode.data)
            current=current.next;
        	newNode.next=current.next;
        	current.next=newNode;
        	}
    	public void display(){
    		if(head==null){
    			System.out.println("Circular linked list is empty");
    			System.exit(0);
    		}
    			Node1 current=head;
    		do{
    			System.out.print(current.data+" ");
    			current=current.next;
    		}while(current!=head);
    		System.out.println();
    }
}  

