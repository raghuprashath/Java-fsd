package practice;

import java.util.Scanner;

public class Project9 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Queue");
		int n=sc.nextInt();
		Queue q=new Queue(n);
		while(true) {
			System.out.println("Do you Want to add element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println("Enter the Element ");
				int x=sc.nextInt();
				q.enqueue(x);
			}
			else {
				break;
			}
		}
		while(true) {
			System.out.println("Do you Want to remove the  element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println(q.dequeue());
			}
			else {
				break;
			}
		}
	}
}
class Queue
{
	int front=-1;
	int rear=-1;
	int queue[];
	int n;
	
	public Queue(int n)
	{
		this.n=n;
		queue=new int[n];
	}
	
	public boolean isFull()
	{
		return rear==n-1;
	}
	
	public boolean isEmpty()
	{
		return front==-1 && rear==-1;
	}
	
	public void enqueue(int data)
	{
		if(isFull())
		{
			System.out.println("Queue is full");
			System.exit(0);
		}
		else if(isEmpty())
		{
			rear=front=0;
			queue[rear]=data;
		}
		else
		{
			rear++;
			queue[rear]=data;
		}
	}
	
	public int dequeue()
	{
		int value=0;
		if(isEmpty())
		{
			System.out.println("Queue is empty");
			System.exit(0);
		}
		else if(front==rear)
		{
			value=queue[front];
			front=rear=-1;
		}
		else
		{
		    value=queue[front];
			front++;
		}
		return value;
	}
}
