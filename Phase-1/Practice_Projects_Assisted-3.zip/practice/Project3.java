package practice;

import java.util.Scanner;

public class Project3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the Array Elements");
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the Range");
		int L=sc.nextInt();
		int R=sc.nextInt();
		int sum=0;
		if(L<=n-1&& R<=n-1) {
			for(int i=L;i<=R;i++) {
				sum+=arr[i];
			}
			System.out.println("The sum is "+sum);
		}
		else {
			System.out.println("The Entered Index is Out of Range");
		}	
	}
}
