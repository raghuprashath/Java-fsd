package practice;

import java.util.Scanner;

public class Project1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Array");
		int n=sc.nextInt();
		int arr[]=new int[n];
		System.out.println("Enter the Array Elements");
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter  the K elements to rotate");
		int k=sc.nextInt();
		rotate(arr,k);
	}
	public static void rotate(int[] arr,int k) {
		int n=arr.length;
		int left=0;
		int right=n-1-k;
		int nextleft=right+1;
		while(left<right) {
			int temp=arr[left];
			arr[left]=arr[right];
			arr[right]=temp;
			right--;
			left++;
		}
		right=n-1;
		while(nextleft<right) {
			int temp=arr[nextleft];
			arr[nextleft]=arr[right];
			arr[right]=temp;
			nextleft++;
			right--;
		}
		left=0;
		right=n-1;
		while(left<right) {
			int temp=arr[left];
			arr[left]=arr[right];
			arr[right]=temp;
			left++;
			right--;
		}
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+" ");
		}
	}
}
