package practice;

import java.util.Scanner;

public class Project8 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of Stack");
		int n=sc.nextInt();
		Stack s=new Stack(n);
		while(true) {
			System.out.println("Do you Want to add element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println("Enter the Element ");
				int x=sc.nextInt();
				s.push(x);
			}
			else {
				break;
			}
		}
		while(true) {
			System.out.println("Do you Want to remove the next element(y/n)");
			char ch=sc.next().charAt(0);
			if(ch=='Y'||ch=='y') {
				System.out.println(s.pop());
			}
			else {
				break;
			}
		}
		System.out.println(s.peek());
		s.display();
	}
}
class Stack{
	int top;
	int n;
	int[] stack;
	Stack(int size){
		stack=new int[size];
		this.n=size;
		top=-1;
	}
	public boolean isEmpty() {
		if(top==-1) {
			return true;
		}
		else {
			return false;
		}
	}
	public boolean isFull() {
		if(top==n-1) {
			return true;
		}
		else {
			return false;
		}
	}
	public void push(int val) {
		if(isFull()) {
			System.out.println("The Stack is Full");
			System.exit(0);
		}
		else {
			stack[++top]=val;
		}
	}
	public int pop() {
		int temp=0;
		if(isEmpty()) {
			System.out.println("The Stack is Empty");
			System.exit(0);
		}
		else {
			temp=stack[top];
			top--;
		}
		return temp;
	}
	public int peek() {
		if(isEmpty()) {
			System.out.println("The Stack is Empty");
		}
		return stack[top];
	}
	public void display() {
		for(int i=top;i>-1;i--) {
			System.out.print(stack[i]+" ");
		}
	}
}