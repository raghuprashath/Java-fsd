package practice;

import java.util.Scanner;

public class Project3 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Array");
		int n=sc.nextInt();
		System.out.println("Enter the Array Elements");
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the element to search");
		int ele=sc.nextInt();
		int x=exponentialSearch(arr,ele);
		if(x!=-1) {
			System.out.println("The Element Found "+x);
		}
		else {
			System.out.println("The Array doesnot contain the element you Searched");
		}
	}
	public static int exponentialSearch(int[] arr,int ele){
		int n=arr.length;
		int i=1;
		while(i<n&&arr[i]<=ele) {
			i*=2;
		}
		return BinarySearch(arr,i/2,Math.min(n-1,i),ele);
	}
	public static int BinarySearch(int[] arr,int i,int min,int ele) {
		int start=i;
		int end=min;
		while(start<=end) {
			int mid=(start+(end-start)/2);
			if(arr[mid]==ele) {
				return arr[mid];
			}
			else if(arr[mid]>ele) {
				end=mid-1;
			}
			else {
				start=mid+1;
			}
		}
		return -1;
	}
}
