package practice;

import java.util.Arrays;
import java.util.Scanner;

public class Project2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Array");
		int n=sc.nextInt();
		System.out.println("Enter the Array Elements");
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the element to search");
		int ele=sc.nextInt();
		int x=BinarySearch(arr,ele);
		if(x!=-1) {
			System.out.println("The Element Found "+x);
		}
		else {
			System.out.println("The Array doesnot contain the element you Searched");
		}
	}
	public static int BinarySearch(int[] arr,int ele){
		Arrays.sort(arr);//because binary search is applicable only to Sorted Array
		int start=0,end=arr.length-1;
		while(start<=end) {
			int mid=(start+(end-start)/2);
			if(arr[mid]==ele) {
				return arr[mid];
			}
			else if(arr[mid]>ele) {
				end=mid-1;
			}
			else {
				start=mid+1;
			}
		}
		return -1;
	}
}