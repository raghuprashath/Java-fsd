package practice;

import java.util.Scanner;

public class Project6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Array");
		int n=sc.nextInt();
		System.out.println("Enter the Array Elements");
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Array before Sorting");
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+" ");
		}
		InsertionSort(arr);
		System.out.println("\nArray After Insertion Sorting");
		for(int i=0;i<n;i++) {
			System.out.print(arr[i]+" ");
		}
	}
	public static void InsertionSort(int[] arr) {
		int n=arr.length;
		for(int i=1;i<n;i++) {
			int temp=arr[i];
			int j=i-1;
			while(j>=0&&temp<=arr[j]){
				arr[j+1]=arr[j];
				j--;
			}
			arr[j+1]=temp;
		}
	}
}
