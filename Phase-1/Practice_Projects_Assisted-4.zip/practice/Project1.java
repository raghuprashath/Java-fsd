package practice;

import java.util.Scanner;

public class Project1 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Size of the Array");
		int n=sc.nextInt();
		System.out.println("Enter the Array Elements");
		int[] arr=new int[n];
		for(int i=0;i<n;i++) {
			arr[i]=sc.nextInt();
		}
		System.out.println("Enter the element to search");
		int ele=sc.nextInt();
		int x=LinearSearch(arr,ele);
		if(x!=-1) {
			System.out.println("The Element Found "+x);
		}
		else {
			System.out.println("The Array doesnot contain the element you Searched");
		}
	}
	public static int LinearSearch(int[] arr,int ele){
		for(int i=0;i<arr.length;i++) {
			if(arr[i]==ele) {
				return arr[i];
			}
			else {
				continue;
			}
		}
		return -1;
	}
}
