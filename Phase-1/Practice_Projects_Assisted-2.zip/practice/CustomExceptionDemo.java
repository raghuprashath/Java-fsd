package practice;
//custom exception is own exception class created by user by extending Exception class.
public class CustomExceptionDemo extends Exception {
	public CustomExceptionDemo(String str) {
		super(str);
	}
}
