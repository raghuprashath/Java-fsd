package practice;

import java.io.*;
import java.util.*;

public class Project7 {
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the file name you want to create and type of file");
			String file=sc.nextLine();
			File f=new File(file);
			System.out.println("Enter the action you want to perform \n 1.Create \n 2.Read\n 3.Update\n 4.Delete");
			int choice;
			while(true) {
				int c=sc.nextInt();
				if(c>0 &&c<5) {
					choice=c;
					break;
				}
				else {
					System.out.println("Enter the choice between 1-4");
				}
			}
			if(choice==1) {
				try
				{
					System.out.println("Enter what you want ro write");
					String str=sc.next();
					FileWriter fw=new FileWriter(f,true);
					BufferedWriter bw=new BufferedWriter(fw);
					bw.write(str);
					bw.flush();
					bw.close();
					
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
			else if(choice==2){
				try
				{
					FileReader fr=new FileReader(f);
					BufferedReader br=new BufferedReader(fr);
					String line=br.readLine();
					while(line!=null)
					{
						System.out.println(line);
						line=br.readLine();
					}
					br.close();
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
			else if(choice==3){
				try
				{
					System.out.println("Enter a text ");
					String str=sc.next().trim();
					FileWriter fw=new FileWriter(f,true);
					BufferedWriter bw=new BufferedWriter(fw);
					bw.write(str);
					bw.flush();
					bw.close();
					
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
				}
			}
			else{
				try
				{
					f.delete();
					System.out.println("File Deleted SuccessFully");
			}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
			}
		}
	}
}
