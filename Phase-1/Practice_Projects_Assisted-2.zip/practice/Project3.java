package practice;

public class Project3 {
	public static void main(String[] args) throws InterruptedException {
		Table s=new Table();
		Thread1 t1=new Thread1(s);
		Thread2 t2=new Thread2(s);
		t1.start();
		t2.start();
	}
}
class Table{
	//synchronized is used to restrict the other threads from accessing the resource until the current threads complete the work
	//Multiple thread cannot access this resource at same time
	synchronized void printSum(int n) {
		for(int i=1;i<=10;i++) {
			System.out.println("The table "+n+"is"+i*n);
		}
		System.out.println("----------------------------");
	}
}
class Thread1 extends Thread{
	Table s;
	public Thread1(Table s) {
		this.s=s;
	}
	public void run() {
		s.printSum(10);
	}
}
class Thread2 extends Thread{
	Table s;
	public Thread2(Table s) {
		this.s=s;
	}
	public void run() {
		s.printSum(20);
	}
	
}