package practice;

public class Project2 {
    public static void main(String[] args) throws InterruptedException {
        Object lock = new Object(); // common lock object
        ThreadDemo1 t = new ThreadDemo1(lock);
        ThreadDemo t1 = new ThreadDemo(lock);
        t.start(); // Start ThreadDemo1 first
        t1.start();
    }
}

class ThreadDemo extends Thread {
    Object lock;

    public ThreadDemo(Object lock) {
        this.lock = lock;
    }

    public void run() {
        printTable(5);
    }

    void printTable(int n) {
        synchronized (lock) {
            for (int i = 1; i <= 10; i++) {
                try {
                    System.out.println(i * n);
                    Thread.sleep(500); // After Each iteration thread waits for 500ms and starts next iteration
                } catch (InterruptedException e) {
                    System.out.println(e.getMessage());
                }
            }
            lock.notify(); // Notify the waiting thread
            System.out.println("-----");
        }
    }
}

class ThreadDemo1 extends Thread {
	Object lock;

    public ThreadDemo1(Object lock) {
        this.lock = lock;
    }

    public void run() {
        synchronized (lock) {
            try {
                lock.wait(); // Wait until notified by the other thread
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        printTable(10);
    }

    void printTable(int n) {
        synchronized (lock) {
            for (int i = 1; i <= 10; i++) {
                try {
                    System.out.println(i * n);
                    Thread.sleep(500); // After Each iteration thread waits for 500ms and starts next iteration
                } catch (InterruptedException e) {
                    System.out.println(e.getMessage());
                }
            }
        }
    }
}
