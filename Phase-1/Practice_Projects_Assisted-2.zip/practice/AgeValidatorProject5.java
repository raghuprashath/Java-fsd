package practice;

public class AgeValidatorProject5 {
	private int age;
	public AgeValidatorProject5(int age) {
		this.age=age;
	}
	public void validate()throws CustomExceptionDemo {
		if(age>=18) {
			System.out.println("You are Eligible to Play in the Team");
		}
		else {
			throw new CustomExceptionDemo("Your age is less than 18 you are not eligible.Custom Exception Raised");
		}
	}
}
