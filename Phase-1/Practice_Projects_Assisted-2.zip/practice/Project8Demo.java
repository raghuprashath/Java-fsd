package practice;

public class Project8Demo {
	/* private variables cannot accessed outside the class even if it is parent
	private int age;
	private String name;
	The binding of data members and member function in single entity is called as Encapsulation
	*/
	int age;
	String name;
	public void display() {
		System.out.println("This is superclass");
	}
	// this is polymorphism -OverLoading
	public void display(String s) {
		System.out.println(s);
	}
	public void details(int age,String name) {
		this.age=age;
		this.name=name;
	}
}
//Single inheritance
class Projectdemo2 extends Project8Demo{
	//this is called method overloading same method as in superclass
	//Polymorphism-Overriding
	public void display() {
		System.out.println("This is Single Inheritance");
	}
	public void printdetails() {
		//Accessing the variables/member functions in super class
		System.out.println("Name "+name+" Age "+age);
	}
}
//Multilevel Inheritance
class Projectdemo3 extends Projectdemo2{
	public void display() {
		System.out.println("This is Multilevel inheritance");
	}
}

//Multiple inheritance not supported in java
//Hierarchical inheritance as both projectdemo2 and projectdemo4 extends same class
class Projectdemo4 extends  Project8Demo{
	public void display() {
		System.out.println("Example of Hierarchical inheritance");
	}
}
