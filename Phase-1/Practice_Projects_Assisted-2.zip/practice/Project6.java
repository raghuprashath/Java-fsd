package practice;

import java.util.Scanner;

public class Project6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int arr[]= {1,2,3,4,5};
		try {
			System.out.println("Enter the index to fetch");
			int index=sc.nextInt();
			array(index,arr);
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.out.println("Array index is out of bound");
			System.out.println(e.getMessage());
		}
		finally {
			System.out.println("Finally Block Called");
		}
	}
	public static void array(int index,int[] arr) {
		System.out.println("The element at "+index +" is "+arr[index]);
	}
}
