package practice;

public class Project1 {
	public static void main(String[] args) {
		//Using thread class 
		Thread t1=new Raghu();
		t1.start();
		//using Runnable interface
		Runnable r=new prashath();
		Thread t2=new Thread(r);
		t2.start();//((Thread)r).start();
	}
}
 class Raghu extends Thread{
	 public void run() {
		 System.out.println("This is using thread class");
	 }
 }
 class prashath implements Runnable{
	 public void run() {
		 System.out.println("This is using Runnable interface");
	 }
 }