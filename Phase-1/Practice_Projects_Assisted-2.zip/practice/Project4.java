package practice;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Project4 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//actual working of program is written inside the try block
		try {
			System.out.println("Enter the Numbers");
			int a=sc.nextInt();
			int b=sc.nextInt();
			System.out.println(a/b);
		}
		//arithmetic exception arises when we try to divide a value by zero
		catch(ArithmeticException e) {
			System.out.println("Cannot Divide by Zero");
			System.out.println(e.getMessage());
		}
		//input mismatch occurs when we try to enter the input of different data type
		catch(InputMismatchException e) {
			System.out.println("Enter Numeric Value");
			System.out.println(e.getMessage());
		}
		//a single try block can have multiple catch block
	}
}
