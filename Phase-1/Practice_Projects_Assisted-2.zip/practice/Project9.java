package practice;

//diamond problems in java refers to multiple inheritance in java.In java multiple inheritance is achieved by interface
//In multiple inheritance there are two parent class and one child class
public class Project9 {
	public static void main(String[] args) {
		Demo r=new Demo();
		r.details();
		r.display();
	}
}
interface one{
	abstract void display();
}
interface two{
	abstract void details();
}
class Demo implements one,two{
	public void details() {	
		System.out.println("This Method overrides the interface two method");
	}
	public void display() {		
		System.out.println("This Method overrides the interface one method");
	}
}