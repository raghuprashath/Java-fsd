package practice;

import java.util.Scanner;

public class Project5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Age");
		int age=sc.nextInt();
		AgeValidatorProject5 a=new AgeValidatorProject5(age);
		try {
			a.validate();
		}catch(CustomExceptionDemo e) {
			System.out.println("\n"+e.getMessage());
		}finally {
			System.out.println("\nfinally block Called");
		}
	}
}
