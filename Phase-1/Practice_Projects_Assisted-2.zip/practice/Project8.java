package practice;

import java.util.Scanner;
/* Pillars of Object oriented are
 1.Inheritance
 2.Encapsulation
 3.Polymorphism
 4.Abstraction */

public class Project8 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		//creating an object for superclass
		Project8Demo p=new Project8Demo();
		//super class method will be called
		p.display();
		p.display("Raghu");
		//creating object for subclass both subclass and superclass methods and variables can be called
		Projectdemo2 p1=new Projectdemo2();
		//calling the method in subclass.The method in superclass will be over-rided.
		p1.display();
		//setting the values to method in parent class by using child class reference
		p1.details(22,"Raghu");
		//calling child class method
		p1.printdetails();
		//creating object for subclass that extends projectdemo2
		Projectdemo3 p2=new Projectdemo3();
		p2.display();// will call method in subclass 2
		p1.display();//will call method in subclass 1
		p.display();//calls super class method

	}
}
