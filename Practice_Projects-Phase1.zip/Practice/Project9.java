package Practice;

import java.util.Scanner;

public class Project9 {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the Arry size");
        int n=sc.nextInt();//getting the size of array
        int[] arr=new int[n];//declaring the array
        System.out.println("Enter the Array elements:");
        for(int i=0;i<n;i++) {
        	arr[i]=sc.nextInt();//getting values for array using loop
        }
        System.out.println("---------------------------------------");
        System.out.println("Elements of the array:");
        for (int i=0;i<n;i++) {
            System.out.println("Index "+i+" "+"Value "+arr[i]);// Accessing elements of the array
        }
        System.out.println("---------------------------------------");
        int max=arr[0];
        for(int i=1;i<n;i++) {
        	if(max<arr[i]) {
        		max=arr[i];//Finding maximum in the Array
        	}
        }
        System.out.println("The maximum in the Array is "+max);
        System.out.println("---------------------------------------");
        int min=arr[0];
        for(int i=1;i<n;i++) {
        	if(min>arr[i]) {
        		min=arr[i];//Finding minimum in the Array
        	}
        }
        System.out.println("The minimum in the Array is "+min);
        System.out.println("---------------------------------------");
        arr[2]=5;// Modifying an element of the array
        System.out.println("After modifying an element:");
        for (int i=0;i<n;i++) {
            System.out.println("Index "+i+" "+"Value "+arr[i]);
        }
        System.out.println("---------------------------------------");
        int sum=0;
        for(int num:arr) {
            sum += num;// Finding the sum of all elements in the array
        }
        System.out.println("Sum "+sum);
        System.out.println("---------------------------------------");
        // Multi-dimensional array
        System.out.println("Enter the number of rows and columns");
        int row =sc.nextInt();
        int column=sc.nextInt();
        int[][] twoDimensional= new int[row][column];
        for (int i=0;i<row;i++) {
            for (int j=0;j<column;j++) {
                twoDimensional[i][j]=sc.nextInt();
            }
        }
        System.out.println("TwoDimensional Array:");
        for (int i=0;i<row;i++) {
            for (int j=0;j<column;j++) {
                System.out.print(twoDimensional[i][j]+" ");
            }
            System.out.println();
        }
     }
}
