package Practice;

public class Project4 {
	public static void main(String[] args) {
		Raghu r=new Raghu();//Default constructor
		Raghu r1=new Raghu("Raghu Prashath",23);//parameterized constructor
	}
}
class Raghu{
	String name;
	int age;
	public Raghu() {
		System.out.println("Default constructor called");
	}
	public Raghu(String name,int age) {
		this.name=name;
		this.age=age;
		display();
	}
	public void display() {
		System.out.println("Name: "+name+"\n"+"Age: "+age);
	}
}