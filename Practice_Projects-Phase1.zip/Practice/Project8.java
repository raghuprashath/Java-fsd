package Practice;

import java.util.Scanner;

public class Project8 {
    public static void main(String[] args) {
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Enter the String:");
        String s =sc.nextLine();
        /*java strings are immutable.It cannot modified.When we modify it creates new object in string pool and consumes Memory.
        so we are converting it to String buffer.It is Synchronized and thread safe*/
        StringBuffer sb = new StringBuffer(s);// Converting string to StringBuffer
        String s1=sc.nextLine();
        sb.append(s1);
        //String Builder are faster then buffer because non synchronized and not thread safe
        StringBuilder sbuild = new StringBuilder(s);// Converting string to StringBuilder
        sbuild.deleteCharAt(0);
        System.out.println("String: " + s);//original string
        System.out.println("StringBuffer: " + sb);// StringBuffer
        System.out.println("StringBuilder: " + sbuild);//StringBuilder

    }
}

