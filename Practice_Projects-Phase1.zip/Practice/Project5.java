package Practice;

import java.util.*;
public class Project5 {
	public static void main(String[] args) {
		System.out.println("Set Implementation");
		set c=new set();
		c.treeSet();
		System.out.println("----");
		c.HashSet();
		System.out.println("----");
		c.LinkedHashset();
		System.out.println("----");
		System.out.println("List Implementation");
		list l=new list();
		l.arrayList();
		System.out.println("----");
		l.LinkedList();
	}
}
class set{
	public void treeSet(){
		Set<String> set=new TreeSet<String>();
		set.add("Kohli");
		set.add("Maxwell");
		set.add("Karthik");
		set.add("Green");
		set.add("Lamror");
		System.out.println("Length of Treeset: "+set.size());
		for(String s:set) {
			System.out.println(s);
		}
	}
	public void HashSet() {
		Set<String> set=new HashSet<String>();
		set.add("Kohli");
		set.add("Maxwell");
		set.add("Karthik");
		set.add("Green");
		set.add("Lamror");
		System.out.println("Length of Hashset: "+set.size());
		for(String s:set) {
			System.out.println(s);
		}
	}
	public void LinkedHashset() {
		Set<String> set=new LinkedHashSet<String>();
		set.add("Kohli");
		set.add("Maxwell");
		set.add("Karthik");
		set.add("Green");
		set.add("Lamror");
		System.out.println("Length of LinkedHashset: "+set.size());
		for(String s:set) {
			System.out.println(s);
		}
	}
}
class list{
	public void arrayList() {
		List<Integer> list=new ArrayList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		System.out.println("Length of ArrayList: "+list.size());
		Iterator i=list.iterator();
		while(i.hasNext()) {
			System.out.print(i.next()+" ");
		}
		System.out.println();
		System.out.println("Is the ArrayList is Empty or not "+list.isEmpty());
	}
	public void LinkedList() {
		List<Integer> list=new LinkedList<Integer>();
		list.add(10);
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		System.out.println("Length of ArrayList: "+list.size());
		Iterator i=list.iterator();
		while(i.hasNext()) {
			System.out.print(i.next()+" ");
		}
		System.out.println();
		System.out.println("Is the Linked List is Empty or not "+list.isEmpty());
	}
}