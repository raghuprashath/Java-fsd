package Practice;
import java.util.*;
public class Project6 {
	public static void main(String[] args) {
		System.out.println("Map Implementation");
		Map m=new Map();
		System.out.println("----");
		System.out.println("HashMap Implementation");
		m.HashMap();
		System.out.println("----");
		System.out.println("LinkedHashMap Implementation");
		m.LinkedHashMap();
		System.out.println("----");
		System.out.println("TreeMap Implementation");
		m.TreeMap();
	}
}
class Map{
	public void HashMap() {
		HashMap<String,Integer> hm = new HashMap<String,Integer>(); 
		hm.put("Raghu", 50); 
		hm.put("prashath",100); 
		hm.put("Arun",150); 
		hm.put("Mishra",200); 
		for (HashMap.Entry<String,Integer> m:hm.entrySet()){ 
         System.out.print(m.getKey() + " "+m.getValue()); 
       } 
	}
	public void LinkedHashMap() {
		LinkedHashMap<String,Integer> lhm = new LinkedHashMap<String,Integer>(); 
		lhm.put("Raghu", 50); 
		lhm.put("prashath",100); 
		lhm.put("Arun",150); 
		lhm.put("Mishra",200); 
		for(String i:lhm.keySet())
		{
			System.out.print(i+"  ");
		}
		System.out.println();
		for(Integer i:lhm.values())
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}
	public void TreeMap() {
		TreeMap<String,Integer> tm = new TreeMap<String,Integer>(); 
		tm.put("Raghu", 50); 
		tm.put("prashath",100); 
		tm.put("Arun",150); 
		tm.put("Mishra",200); 
		for(String i:tm.keySet())
		{
			System.out.print(i+"  ");
		}
		System.out.println();
		for(Integer i:tm.values())
		{
			System.out.print(i+" ");
		}
		System.out.println();
	}
}