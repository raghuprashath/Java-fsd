package Practice;

public class Project3 {
	public static void main(String[] args) {
		//static Methods can be called using class name
		Display.display2();
		int a=Display.display3(5,5);
		System.out.println(a);
		Display d=new Display();
		d.display1();
		int b=d.display4();
		System.out.println(b);
		d.display5(9,8);
		int c=d.display6(6,6);
		System.out.println(c);
		boolean e=d.display7(5, 5);
		System.out.println(e);
	}
}
class Display{
	int a=1,b=1;
	public void display1() {
		System.out.println("NO Return type and no arguments");
	}
	public static void display2() {
		System.out.println("Static method called");
	}
	public static int display3(int x,int y) {
		System.out.println("Static method with return type");
		//return a+b; throws error because a and b are non static
		return x+y;
	}
	public int display4() {
		System.out.println("Return type method called");
		return a+b;
	}
	public void display5(int a,int b) {
		System.out.println("Methods with arguments and no return type");
	}
	public int display6(int a,int b) {
		System.out.println("Method with argument and return type");
		return a+b;
	}
	public  boolean display7(int x,int y) {
		return x==y;
	}
}
