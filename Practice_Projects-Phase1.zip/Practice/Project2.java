package Practice;

public class Project2 {
		public static void main(String[] args) {
			Parent1 p=new Parent1(20,"raghu");
			System.out.println("Public example");
			p.display();
			System.out.println(p.age);
			System.out.println(p.rollno);
			System.out.println("-------------------------------");
			System.out.println("Private example");
			//p.display1() and p.name; this will show error because private is not accessed outside the class
			p.setName("prashath");
			System.out.println(p.getName());//getter and setter methods are used to access private variables
			System.out.println("-------------------------------");
			System.out.println("Protected example");
			p.display2();
			System.out.println("-------------------------------");
			System.out.println("Default example");
			p.display3();
		}
}
class Parent1{
	int age=0;//this is default variable
	public int rollno=10;
	private String name=null;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Parent1(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	//public methods and variables are accessed anywhere from outside
	public void display() {
		System.out.println("This is Public Method");
		System.out.println("Name: "+name+" "+"Age: "+age);
	}
	//private method and method cannot accessed outside the class
	private void display1() {
		System.out.println("This is private method");
		System.out.println("Name: "+name+"Age: "+age);
	}
	//protected can be accessed in class and subclass 
	protected void display2() {
		System.out.println("This is Protected Method");
		System.out.println("Name: "+name+" "+"Age: "+age);
	}
	// Default is package private.Cannot accessed outside the package
	void display3() {
		System.out.println("This is Default access Modifier");
		System.out.println("Name: "+name+" "+"Age: "+age);
	}
}
