package Practice;

public class Project1 {
	public static void main(String[] args) {
		//primitive type
		/*
		int a=10;
		//Implicit type Casting
		float b=a;
		System.out.println(b);
		//Explicit type casting
		int c=(int) b;
		System.out.println(c);
		*/
		//Reference type
		Parent p=new Child();//up casting
		p.display();
		//p.welcome(); will get compilation error because reference is of class parent which does not have welcome method
		Child c=(Child) p;//Down casting
		c.display();
		c.welcome();
	}
}
class Parent{
	public void display() {
		System.out.println("Method in Parent class");
	}
}
class Child extends Parent{
	public void display() {
		System.out.println("Method in Child class");
	}
	public void welcome() {
		System.out.println("Welcome to child class");
	}
}