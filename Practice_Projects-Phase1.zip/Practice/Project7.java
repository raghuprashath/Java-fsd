package Practice;

import java.util.Scanner;

public class Project7 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Name");
		String name=sc.nextLine();
		Outerclass o=new Outerclass(name);
		o.callinnerclass();
	}
}
class Outerclass {
    String name;
    public Outerclass(String name) {
        this.name=name;
    }
    public void callinnerclass() {
        Innerclass i = new Innerclass();//Inner class reference
        i.innerMethod();//calling the inner class method
    }
    class Innerclass {//Inner class
        public void innerMethod() {
            System.out.println("Innerclass calling outerclass value: " +name);
        }
    }
}