package Practice;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Project10 {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String");//getting String from user
		String s=sc.nextLine();
		System.out.println("Enter a pattern");//getting match to check match
		String p=sc.nextLine();
		Pattern pattern = Pattern.compile(p);
		Matcher m = pattern.matcher(s);
		while (m.find())
		{
			System.out.println("Pattern found "+ m.group());
		}
	}

}
