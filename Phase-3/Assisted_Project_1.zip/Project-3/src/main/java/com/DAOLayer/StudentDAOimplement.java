package com.DAOLayer;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

import com.beans.StudentInfo;

public class StudentDAOimplement implements StudentDAO {
	
	private DataSource datasource;
	private JdbcTemplate temp;
	
	public DataSource getDatasource() {
		return datasource;
	}

	public void setDatasource(DataSource datasource) {
		this.datasource = datasource;
		temp=new JdbcTemplate(datasource);
		System.out.println("Database Connection Successfull");
	}

	@Override
	public String adddata(StudentInfo std) {
		String res="Err";
		String query="INSERT INTO DEMO(RNO,NAME,AGE)VALUES(?,?,?)";
		int info=temp.update(query,new Object[] {std.getRno(),std.getName(),std.getAge()});
		if(info>=1) {
			res="success";
		}
		return res;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public List<StudentInfo> viewAll() {
		List<StudentInfo> info=new ArrayList<StudentInfo>();
		info=temp.query("SELECT * FROM DEMO",new BeanPropertyRowMapper(StudentInfo.class));
		return info;
	}

	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	@Override
	public StudentInfo search(int rno) {
		StudentInfo std=null;
		String query="SELECT * FROM DEMO WHERE RNO=?";
		std= (StudentInfo) temp.queryForObject(query,new Object[] {rno},new BeanPropertyRowMapper(StudentInfo.class));
		return std;
	}

}
