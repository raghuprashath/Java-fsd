package com.DAOLayer;

import java.util.List;

import com.beans.StudentInfo;

public interface StudentDAO {
	
	public List<StudentInfo> viewAll();
	public String adddata(StudentInfo std);
	public StudentInfo search(int id);
}
