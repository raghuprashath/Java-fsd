package com.apps;

import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.DAOLayer.StudentDAO;
import com.beans.StudentInfo;

public class StudentApp {

	public static void main(String[] args) {
		
		ApplicationContext fact=new ClassPathXmlApplicationContext("dbconfig.xml");
		StudentDAO std=(StudentDAO)fact.getBean("conObj");
		StudentInfo info=null;
		Scanner sc=new Scanner(System.in);
		while(true) {
			System.out.println(" 1.Add Details \n 2.View Details \n 3.Search Student Detail \n 4.Break");
			int ch=sc.nextInt();
			switch (ch) {
			case 1:
				info=new StudentInfo();
				System.out.println("Roll No: ");
				info.setRno(sc.nextInt());
				System.out.println("Name: ");
				info.setName(sc.next());
				System.out.println("Age: ");
				info.setAge(sc.nextInt());
				if(std.adddata(info).equals("success")) {
					System.out.println("Information Added");
				}
				else {
					System.out.println("Cannot add");
				}
				break;
			case 2:
				List<StudentInfo> lst=std.viewAll();
				if(lst.isEmpty()) {
					System.out.println("No Details found");
				}
				else {
					for(StudentInfo s:lst) {
						System.out.println("RNO: "+s.getRno());
						System.out.println("Name: "+s.getName());
						System.out.println("Age: "+s.getAge());
						System.out.println("-----------------");
					}
				}
				break;
			case 3:
				System.out.println("Enter the Rno");
				int n=sc.nextInt();
				info=std.search(n);
				if(info!=null) {
					System.out.println("RNO: "+info.getRno()+"\nName:"+info.getName()+"\nAge:"+info.getAge());
				}
				else {
					System.out.println("Product Not FOund");
				}
				break;
			case 4:
				System.out.println("Thanks Visit Again");
				System.exit(0);
			default:
				break;
			}
		}
	}
}
