package com.app;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import com.beans.*;
public class StudentApp {

	public static void main(String[] args) {
		//Resource rs=new ClassPathResource("config.xml");
		//BeanFactory fact=new XmlBeanFactory(rs);
		ApplicationContext fact=new ClassPathXmlApplicationContext("config.xml");
		Student std=(Student) fact.getBean("stdObj");
		System.out.println("Student Roll no: "+std.getRollno());
		System.out.println("Student Name: "+std.getName());
		System.out.println("Student Mark: "+std.getMarks());
	}
}
