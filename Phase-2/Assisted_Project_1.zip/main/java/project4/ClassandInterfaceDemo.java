package project4;

import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;

/**
* Servlet implementation class InterfaceDemo
*/
@WebServlet("/ClassandInterfaceDemo")
public class ClassandInterfaceDemo implements Servlet {
        
        ServletConfig config=null;
          public void init(ServletConfig config){
              this.config=config;
              System.out.println("Initialize Method Called");
           }

           public void service(ServletRequest req,ServletResponse res)
           throws IOException,ServletException{
               res.setContentType("text/html");
               PrintWriter out=res.getWriter();
               out.println("<html><body>");
               out.print("Service Method called ");
               out.println("</body></html>");
           }
           public void destroy(){
               System.out.println("Destroy Method Called");
           }
           public ServletConfig getServletConfig(){
               return config;
           }
           public String getServletInfo(){
               return "Servlet Info Method Called";
           }
}
