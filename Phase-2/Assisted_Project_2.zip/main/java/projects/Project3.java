package projects;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mysql.cj.protocol.Resultset;

import dbConnection.DbConnection;

/**
 * Servlet implementation class Project3
 */
@WebServlet("/Project3")
public class Project3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Project3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		try {	
			//connection
			Connection con=DbConnection.getConnection();
			//statement=Prepared Statement
			PreparedStatement p=con.prepareStatement("INSERT INTO EPRODUCT VALUES('Salt',100,'22-12-2021')");
			p.executeUpdate();
			//ResultSet statement
			ResultSet res= p.executeQuery("SELECT * FROM EPRODUCT");
			while(res.next()) {
				out.print(res.getString("name")+"    "+res.getFloat("price")+"    "+res.getString("dateadded")+"<br>");
			}	 
		}catch (Exception e) {
			out.print("cannot make connection");
			System.out.println(e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
