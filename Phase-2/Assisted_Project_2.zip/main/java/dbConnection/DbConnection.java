package dbConnection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
	static boolean c=true;
	public static Connection getConnection()
	{
		Connection conObj = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			conObj = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce","root", "223004067@Sastra");
			c=false;
			System.out.println("Database Connected SuccessFully");
		} catch (Exception e) {
			System.out.println(e);
		} 
		return conObj;
	}
}